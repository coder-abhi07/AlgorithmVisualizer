import React, {Component} from 'react';

class Profile extends Component {
    render() {
        return (
            <div>
                <h1>
                    Profile page
                </h1>
            </div>
        );
    }
}

export default Profile;